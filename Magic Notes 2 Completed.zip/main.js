
show()
let addbtn = document.getElementById('btn')
addbtn.addEventListener('click', addNote)
function addNote(e) {
   e.preventDefault()
   let text = document.getElementById('textInput').value
   let title = document.getElementById('noteTitle').value
   let notes = localStorage.getItem('notes')

   if (notes == null) {
      notesObj = []
   } else {
      notesObj = JSON.parse(notes);
   }

   if (title.length == 0 || text.length == 0) {
      showAlert()
   } else {
      let myNotes = {
         title: title,
         text: text,
         color : 'white',
         checkBoxC : null
      }
      notesObj.push(myNotes)
      localStorage.setItem('notes', JSON.stringify(notesObj))
      
      show()
      let noteTitle = document.getElementById('noteTitle') 
      let textInput = document.getElementById('textInput')
      noteTitle.value = ''
      textInput.value = ''
      //   console.log(notesObj);}

}

   }

  
 function change(index) {
   
   console.log(index);
   let notes = localStorage.getItem('notes')
 
   if (notes == null) {
     notesObj = []
   } else {
     notesObj = JSON.parse(notes)
     //If any there
   }
 
   console.log(notesObj[index]);
    let target = document.getElementById(`note ${index}`)
   let checkBox = document.getElementsByClassName('check')
   console.log(checkBox);
   if (checkBox[index].checked) {
     notesObj[index].color = "#fdb1c1ff"
        target.style.backgroundColor = "#fdb1c1ff"
        notesObj[index].checkBoxC = 'checked'
   } 
   if (!checkBox[index].checked) {
     notesObj[index].color = "white"
     target.style.backgroundColor = "white"
        notesObj[index].checkBoxC = null
   }
    
   localStorage.setItem('notes', JSON.stringify(notesObj))
 } 
   function show() {
      let place = document.getElementById('addNote')
      let notes = localStorage.getItem('notes')

      if (notes == null) {
         notesObj = []
      } else {
         notesObj = JSON.parse(notes)
         //If any there
      }
      let html = ''
      notesObj.forEach(function(element, index) {
         
         html += `<div class="noteCard my-2 mx-2 card" style="width: 18rem;display:inline-block;background-color:${element.color}" id="note ${index}"  >
                    <div class="card-body" >
                        <h5 class="card-title">${element.title} </h5>
                        <p class="card-text"> ${element.text}</p>
                        <button id="${index}"onclick="deleteNote(this.id)" class="btn btn-primary" style="position:relative;bottom:-29px">Delete Note</button>
                    </div>
               <form>
               <input type="checkBox" style="position:relative;left:90%;" id="${index}" onclick="change(this.id)" class="check" ${element.checkBoxC}>
                </div></form>`
                
                
      })
      if (notesObj.length != 0) {
         place.innerHTML = html
      } else {
         place.innerHTML = 'Nothing to see here! Add notes to see them'
      }

   }

   function deleteNote(index) {
      let notes = localStorage.getItem('notes')

      if (notes == null) {
         notesObj = []
      } else {
         notesObj = JSON.parse(notes);
      }
      notesObj.splice(index, 1)
      localStorage.setItem('notes', JSON.stringify(notesObj))
      show();
   }


   //If I face any problem related to JSON ,I will clear the localStorage at first.
   let search = document.getElementById('search')
   search.addEventListener('input', suggestion)

   function suggestion() {
      let searchInput = search.value.toLowerCase()
      let allNote = document.getElementsByClassName('noteCard')
      Array.from(allNote).forEach(function(element) {
         let cardTxt = element.getElementsByTagName("p")[0].innerText;
         if (cardTxt.toLocaleLowerCase().includes(searchInput)) {
            element.style.display = 'block'
         } else {
            element.style.display = 'none'
         }})}
function showAlert() {
  let position = document.getElementById('alert')
   position.innerHTML = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
     <strong>Warning!</strong> You should check in on some of those fields below.
     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
   </div>`
    setTimeout(function() {
       position.innerHTML = ''
    }, 5000)
   
}

